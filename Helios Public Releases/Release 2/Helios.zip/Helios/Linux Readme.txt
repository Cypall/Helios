Required Libraries (according to openSUSE 10.2)
- liblua (lua-devel rpm)
- libc (zlib-devel rpm)
- libncurses (ncurses-devel rpm)
