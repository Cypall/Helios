-- _________________________________________________ --
--/                                                 \--
--|    _    _          _   _                        |--
--|   | |  | |        | | (_)                       |--
--|   | |__| |   ___  | |  _    ___    ___          |--
--|   |  __  |  / _ \ | | | |  / _ \  / __|         |--
--|   | |  | | |  __/ | | | | | (_) | \__ \         |--
--|   |_|  |_|  \___| |_| |_|  \___/  |___/         |--
--|                                                 |--
--|-------------------------------------------------|--
--| 29/12/2007                                      |--
--|   -First Version for Helios  [Spre]             |--
--|-------------------------------------------------|--
--| Credits: Gravity                                |--
--|          Yaros                                  |--
--|-------------------------------------------------|--
--| Notes:                                          |--
--|                                                 |--
--|                                                 |--
--\_________________________________________________/--
warp("new_2-1","novicetraining2warp001",148,112,2,3)
function novicetraining2warp001()
	moveto("new_2-2",100,9)
end

warp("new_2-2","novicetraining2warp002",100,6,3,1)
function novicetraining2warp002()
	moveto("new_2-1",144,112)
end

warp("new_2-2","novicetraining2warp003",126,106,2,4)
function novicetraining2warp003()
	moveto("new_2-2",160,171)
end

warp("new_2-2","novicetraining2warp004",46,172,2,4)
function novicetraining2warp004()
	moveto("new_2-2",78,106)
end

warp("new_2-2","novicetraining2warp005",73,106,2,4)
function novicetraining2warp005()
	moveto("new_2-2",41,172)
end

warp("new_2-2","novicetraining2warp006",156,171,2,4)
function novicetraining2warp006()
	moveto("new_2-2",123,106)
end
