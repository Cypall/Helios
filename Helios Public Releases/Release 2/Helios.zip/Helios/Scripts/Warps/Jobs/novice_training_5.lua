-- _________________________________________________ --
--/                                                 \--
--|    _    _          _   _                        |--
--|   | |  | |        | | (_)                       |--
--|   | |__| |   ___  | |  _    ___    ___          |--
--|   |  __  |  / _ \ | | | |  / _ \  / __|         |--
--|   | |  | | |  __/ | | | | | (_) | \__ \         |--
--|   |_|  |_|  \___| |_| |_|  \___/  |___/         |--
--|                                                 |--
--|-------------------------------------------------|--
--| 29/12/2007                                      |--
--|   -First Version for Helios  [Spre]             |--
--|-------------------------------------------------|--
--| Credits: Gravity                                |--
--|          Yaros                                  |--
--|-------------------------------------------------|--
--| Notes:                                          |--
--|                                                 |--
--|                                                 |--
--\_________________________________________________/--

warp("new_5-1","novicetraining5warp001",148,112,2,3)
function novicetraining5warp001()
	moveto("new_5-2",100,9)
end

warp("new_5-2","novicetraining5warp002",100,6,3,1)
function novicetraining5warp002()
	moveto("new_5-1",144,112)
end

warp("new_5-2","novicetraining5warp003",126,106,2,4)
function novicetraining5warp003()
	moveto("new_5-2",160,171)
end

warp("new_5-2","novicetraining5warp004",46,172,2,4)
function novicetraining5warp004()
	moveto("new_5-2",78,106)
end

warp("new_5-2","novicetraining5warp005",73,106,2,4)
function novicetraining5warp005()
	moveto("new_5-2",41,172)
end

warp("new_5-2","novicetraining5warp006",156,171,2,4)
function novicetraining5warp006()
	moveto("new_5-2",123,106)
end
