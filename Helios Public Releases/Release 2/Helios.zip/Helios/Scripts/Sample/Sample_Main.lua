require("Scripts/Sample/MenuAndVars")
require("Scripts/Sample/Zeny")